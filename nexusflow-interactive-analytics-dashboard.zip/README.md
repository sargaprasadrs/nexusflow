# NexusFlow Project

NexusFlow is a responsive revenue intelligence dashboard backed by MongoDB. The browser only calls the API: the MongoDB connection string remains on the Node server.

## Configure MongoDB

1. Create a MongoDB Atlas cluster and a database user with read/write access to the `nexusflow` database.
2. Allow your development or deployment server IP address in Atlas Network Access.
3. Copy `.env.example` to `.env` and fill in `MONGODB_URI` and a strong `NEXUSFLOW_SEED_TOKEN`.

The API reuses a single MongoDB client connection, which avoids opening a fresh connection for every dashboard request.

## Run locally

1. Build the frontend: `npm run build`
2. Start the full application server with Node 20+: `node --env-file=.env server.mjs`
3. Seed the sample opportunity data once:

```bash
curl -X POST http://localhost:3001/api/seed \
  -H "Authorization: Bearer <your-NEXUSFLOW_SEED_TOKEN>"
```

Open `http://localhost:3001`. The dashboard status line changes to `MongoDB connected - live project data` after the API responds successfully.

For Vite hot-reload development, run the Node server above and `npm run dev` in another terminal. The `VITE_API_BASE_URL` value in `.env` lets the Vite app call the local API at port 3001.

## API

- `GET /api/dashboard?range=7d|30d|90d&segment=All%20segments|Enterprise|Mid-market|SMB` returns metrics, chart series, channel totals, and table rows from MongoDB.
- `GET /api/health` verifies the database connection.
- `POST /api/seed` resets and adds the deterministic NexusFlow sample data. It requires `Authorization: Bearer <NEXUSFLOW_SEED_TOKEN>`.

## Data model

The dashboard reads the `opportunities` collection. Each record contains company details, owner, segment, source, stage, current value, prior value, and timestamps. Create or update documents in this collection to have the dashboard reflect your real project data.