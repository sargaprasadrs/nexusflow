import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { getDatabase } from "./server/mongodb.mjs";
import { createSeedOpportunities } from "./server/seed-data.mjs";

const port = Number(process.env.PORT || 3001);
const allowedSegments = new Set(["All segments", "Enterprise", "Mid-market", "SMB"]);
const allowedRanges = new Map([["7d", 7], ["30d", 30], ["90d", 90]]);
const sources = ["Inbound", "Outbound", "Partners", "Product-led"];

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": process.env.CORS_ORIGIN || "http://localhost:5173",
    "Access-Control-Allow-Headers": "Authorization, Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  });
  response.end(JSON.stringify(payload));
}

function startOfRange(days) {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - days + 1);
  return start;
}

function dateKey(date) {
  return date.toISOString().slice(0, 10);
}

function relativeUpdatedAt(date) {
  const now = new Date();
  const ageInDays = Math.floor((now.getTime() - date.getTime()) / 86400000);
  if (ageInDays === 0) return `Today, ${date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}`;
  if (ageInDays === 1) return "Yesterday";
  return date.toLocaleDateString("en-US", { month: "short", day: "2-digit" });
}

function formatOpportunity(document) {
  const now = Date.now();
  return {
    company: document.company,
    initials: document.initials,
    owner: document.owner,
    segment: document.segment,
    value: document.value,
    stage: document.stage,
    updated: relativeUpdatedAt(document.updatedAt),
    age: Math.max(0, Math.floor((now - document.updatedAt.getTime()) / 86400000)),
  };
}

async function dashboardData(searchParams) {
  const range = allowedRanges.has(searchParams.get("range")) ? searchParams.get("range") : "30d";
  const days = allowedRanges.get(range);
  const requestedSegment = searchParams.get("segment");
  const segment = allowedSegments.has(requestedSegment) ? requestedSegment : "All segments";
  const match = { createdAt: { $gte: startOfRange(days) } };
  if (segment !== "All segments") match.segment = segment;

  const database = await getDatabase();
  const collection = database.collection("opportunities");
  const [opportunities, dailyRows, summaryRows, channelRows] = await Promise.all([
    collection.find(match).sort({ updatedAt: -1 }).limit(100).toArray(),
    collection.aggregate([
      { $match: match },
      { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, pipeline: { $sum: "$value" }, previous: { $sum: "$previousValue" }, qualified: { $sum: { $cond: [{ $ne: ["$stage", "Discovery"] }, 1, 0] } } } },
      { $sort: { _id: 1 } },
    ]).toArray(),
    collection.aggregate([
      { $match: match },
      { $group: { _id: null, pipeline: { $sum: "$value" }, previous: { $sum: "$previousValue" }, qualified: { $sum: { $cond: [{ $ne: ["$stage", "Discovery"] }, 1, 0] } }, opportunities: { $sum: 1 }, wins: { $sum: { $cond: [{ $eq: ["$stage", "Closed won"] }, 1, 0] } }, won: { $sum: { $cond: [{ $eq: ["$stage", "Closed won"] }, "$value", 0] } } } },
    ]).toArray(),
    collection.aggregate([
      { $match: match },
      { $group: { _id: "$source", current: { $sum: "$value" }, previous: { $sum: "$previousValue" } } },
    ]).toArray(),
  ]);

  const dailyByDate = new Map(dailyRows.map((row) => [row._id, row]));
  const daily = Array.from({ length: days }, (_, index) => {
    const date = startOfRange(days);
    date.setDate(date.getDate() + index);
    const row = dailyByDate.get(dateKey(date));
    return { date: date.toISOString(), pipeline: row?.pipeline || 0, previous: row?.previous || 0, qualified: row?.qualified || 0 };
  });
  const summary = summaryRows[0] || { pipeline: 0, previous: 0, qualified: 0, opportunities: 0, wins: 0, won: 0 };
  const channelsBySource = new Map(channelRows.map((row) => [row._id, row]));

  return {
    generatedAt: new Date().toISOString(),
    summary: {
      pipeline: summary.pipeline,
      change: summary.previous ? (summary.pipeline - summary.previous) / summary.previous * 100 : 0,
      qualified: summary.qualified,
      closeRate: summary.opportunities ? summary.wins / summary.opportunities * 100 : 0,
      won: summary.won,
    },
    daily,
    channels: sources.map((name) => ({ name, current: channelsBySource.get(name)?.current || 0, previous: channelsBySource.get(name)?.previous || 0 })),
    opportunities: opportunities.map(formatOpportunity),
  };
}

async function seedDatabase(request, response) {
  const expectedToken = process.env.NEXUSFLOW_SEED_TOKEN;
  if (!expectedToken || request.headers.authorization !== `Bearer ${expectedToken}`) {
    sendJson(response, 403, { error: "Seed endpoint is disabled or the authorization token is invalid" });
    return;
  }

  const database = await getDatabase();
  const collection = database.collection("opportunities");
  await collection.deleteMany({ seed: "nexusflow-v1" });
  const seed = createSeedOpportunities();
  await collection.insertMany(seed);
  await collection.createIndex({ createdAt: -1, segment: 1 });
  await collection.createIndex({ updatedAt: -1 });
  sendJson(response, 201, { inserted: seed.length, message: "NexusFlow sample data seeded" });
}

async function serveApp(response) {
  try {
    const html = await readFile(resolve(process.cwd(), "dist", "index.html"));
    response.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    response.end(html);
  } catch {
    response.writeHead(503, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Build the frontend first with: npm run build");
  }
}

const server = createServer(async (request, response) => {
  const url = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`);
  if (request.method === "OPTIONS") {
    sendJson(response, 204, {});
    return;
  }

  try {
    if (request.method === "GET" && url.pathname === "/api/dashboard") {
      sendJson(response, 200, await dashboardData(url.searchParams));
      return;
    }
    if (request.method === "POST" && url.pathname === "/api/seed") {
      await seedDatabase(request, response);
      return;
    }
    if (request.method === "GET" && url.pathname === "/api/health") {
      await getDatabase();
      sendJson(response, 200, { status: "ok", database: process.env.MONGODB_DB || "nexusflow" });
      return;
    }
    await serveApp(response);
  } catch (error) {
    console.error("NexusFlow server error", error);
    sendJson(response, 500, { error: "Unable to complete the request. Check MongoDB configuration and network access." });
  }
});

server.listen(port, () => {
  console.log(`NexusFlow server is running at http://localhost:${port}`);
});